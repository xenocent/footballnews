var webPush = require('web-push');
 
const vapidKeys = {
   "publicKey": "BHatdMnEbIk9dI-2DIqGXDEnte8ekhtX4ibQZO73TswEYJ6ytFIXHINuiCvdNJK5OGSenlbHsE0oJTt75EFzPg0",
   "privateKey": "EDO4j7gj5_6p7Lw6VEi-DRwAzXSMF02LTd93ajefsW0"
};
 
 
webPush.setVapidDetails(
   'mailto:budisetiawan760@gmail.com',
   vapidKeys.publicKey,
   vapidKeys.privateKey
)
var pushSubscription = {
   "endpoint": "https://fcm.googleapis.com/fcm/send/ejcrBwIgW_w:APA91bHZkjZdQoUZbr6Qdo5LfLCtDrI2xfu_50L8T_2eND9PZi8s0Yz1RwGgU7bZeiJu7j3MJSUXUaSn6rLePU41DHNvwuObMLtN_t0y-JXOAxLLHrKmBFgTPjTgeZ3LXYgk02QCqPj6",
   "keys": {
       "p256dh": "BLAJfKXDvWkakuYmy53HQFPeHsfzmqHiSSfITtHIwYZxTrskhqTuTnSRFs4e/zeebYOs514QnjTQJ9Uivwr+pU0=",
       "auth": "3dAcL+vaGkt4IaIRpqNqOg=="
   }
};
var payload = 'Selamat! Aplikasi Anda sudah dapat menerima push notifikasi!';
 
var options = {
   gcmAPIKey: '584943448460',
   TTL: 60
};
webPush.sendNotification(
   pushSubscription,
   payload,
   options
);